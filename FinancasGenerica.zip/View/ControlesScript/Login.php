<?php

header('Location: ../Login.php');
?>

